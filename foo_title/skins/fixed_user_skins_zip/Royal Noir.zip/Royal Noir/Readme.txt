Skin: Royale Noir v1.1
Author: Jacob Brett (jacobbrett@hotmail.com): http://www.last.fm/user/jacobbrett

Credit:
Based on the 'Royal Noir' skin by oddbasket for Windows XP: http://www.deviantart.com/deviation/44294818
'Thin Skin version 2' by Roman Plasil used as skin template.
Uses some graphics from 'Royal Noir' by oddbasket.
Uses modified code from the 'Turquoise' skin by Tom Barlow.

Changelog:
----------------
v1.1
-redone shadows
-added play/pause functionality (though buggy on skin initialisation)